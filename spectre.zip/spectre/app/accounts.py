"""
app/accounts.py
----------------
Login / license-account system for the SPECTRE public portal.

This module is intentionally standalone (only needs a DB-API 2.0
sqlite3 connection with row_factory=sqlite3.Row) so it can be shared
by both the Flask app (via app.database.get_db) and the standalone
Telegram bot process (telegram_bot.py), which opens its own sqlite3
connection to the same data/spectre.db file.

Nothing in here touches the existing categories/resources/usage_log
tables or any existing route.

── Expiry accounting model ───────────────────────────────────────────────
Timed accounts do NOT expire against a fixed wall-clock deadline.
Instead each account carries a `remaining_seconds` budget that is only
decremented while the backend process is actually alive and ticking
(see tick_accounts()). Whenever a process starts up it calls
resume_accounts() first, which resets the tick reference point to
"now" WITHOUT subtracting anything — this is what makes any downtime
(closed Termux, killed Python, server reboot, new Cloudflared URL,
tools left off for days) invisible to the countdown. `expires_at` is
kept only as a human-readable *estimate* of the deadline assuming the
backend keeps running continuously from now; the authoritative value
is always remaining_seconds.
"""

import re
from datetime import datetime, timedelta

from werkzeug.security import generate_password_hash, check_password_hash

# ── Duration format ──────────────────────────────────────────────────────────
# m = minit (minute), j = jam (hour), h = hari (day), b = bulan (~30 days),
# t = tahun (~365 days). Tokens may be combined, e.g. "1t2b3h".
_DURATION_RE = re.compile(r"(\d+)\s*([mjhbt])", re.IGNORECASE)

_UNIT_SECONDS = {
    "m": 60,
    "j": 60 * 60,
    "h": 60 * 60 * 24,
    "b": 60 * 60 * 24 * 30,
    "t": 60 * 60 * 24 * 365,
}


class DurationError(ValueError):
    pass


def parse_duration(token):
    """Parse a duration string like '80h', '30m', '7h', '1t2b' into a timedelta.
    Raises DurationError if the token has no valid m/j/h/b/t parts."""
    token = (token or "").strip().replace(" ", "").lower()
    matches = _DURATION_RE.findall(token)
    if not matches:
        raise DurationError(f"Invalid duration format: {token!r}")
    seconds = 0
    for n, unit in matches:
        seconds += int(n) * _UNIT_SECONDS[unit]
    return timedelta(seconds=seconds)


def _now():
    return datetime.utcnow()


def _iso(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S") if dt else None


def _parse_iso(s):
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


# ── Schema ───────────────────────────────────────────────────────────────────

def ensure_schema(con):
    """Create the accounts/telegram-config tables if they don't exist yet,
    and add any newer columns to an existing accounts table. Purely
    additive — never touches existing app tables (categories/resources/
    usage_log/meta)."""
    con.executescript("""
        CREATE TABLE IF NOT EXISTS accounts (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            username            TEXT NOT NULL UNIQUE,
            password_hash       TEXT NOT NULL,
            is_permanent        INTEGER DEFAULT 0,
            remaining_seconds   INTEGER,
            last_tick_at        TEXT,
            expires_at          TEXT,
            is_locked           INTEGER DEFAULT 0,
            created_at          TEXT DEFAULT (datetime('now')),
            created_by          TEXT DEFAULT 'admin',

            session_token       TEXT,
            device_id           TEXT,
            device_fingerprint  TEXT,
            device_name         TEXT,
            device_os           TEXT,
            device_browser      TEXT,
            device_platform     TEXT,
            device_public_ip    TEXT,
            device_timezone     TEXT,
            device_language     TEXT,
            device_screen       TEXT,
            device_user_agent   TEXT,

            first_login_at      TEXT,
            last_login_at       TEXT,
            last_active_at      TEXT
        );

        CREATE INDEX IF NOT EXISTS idx_accounts_username ON accounts(username);
        CREATE INDEX IF NOT EXISTS idx_accounts_session   ON accounts(session_token);

        CREATE TABLE IF NOT EXISTS telegram_config (
            key   TEXT PRIMARY KEY,
            value TEXT
        );
    """)
    con.commit()

    # Migrate older DBs that predate remaining_seconds / last_tick_at.
    existing_cols = {row[1] for row in con.execute("PRAGMA table_info(accounts)").fetchall()}
    if "remaining_seconds" not in existing_cols:
        con.execute("ALTER TABLE accounts ADD COLUMN remaining_seconds INTEGER")
    if "last_tick_at" not in existing_cols:
        con.execute("ALTER TABLE accounts ADD COLUMN last_tick_at TEXT")
    if "is_locked" not in existing_cols:
        con.execute("ALTER TABLE accounts ADD COLUMN is_locked INTEGER DEFAULT 0")
    con.commit()


# ── Config (bot token / admin id) ───────────────────────────────────────────

def get_config(con, key, default=None):
    row = con.execute("SELECT value FROM telegram_config WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_config(con, key, value):
    con.execute(
        "INSERT INTO telegram_config(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value)
    )
    con.commit()


def seed_default_config(con):
    """Pre-fill the Telegram config with sane defaults on first run only —
    never overwrites a value the admin has already set."""
    con.execute(
        "INSERT OR IGNORE INTO telegram_config(key,value) VALUES('admin_id','7624612389')"
    )
    con.execute(
        "INSERT OR IGNORE INTO telegram_config(key,value) VALUES('bot_token','7663188091:AAFdU1_4_qT6vCXge0bydxSf8wHzbpZ8v74')"
    )
    con.commit()


# ── Account CRUD ─────────────────────────────────────────────────────────────

class AccountError(ValueError):
    pass


def create_account(con, username, password, duration_token=None):
    username = (username or "").strip()
    if not username or not password:
        raise AccountError("Username and password are required.")

    existing = con.execute("SELECT id FROM accounts WHERE username=?", (username,)).fetchone()
    if existing:
        raise AccountError(f"Account '{username}' already exists.")

    now = _now()
    if duration_token:
        delta = parse_duration(duration_token)
        remaining_seconds = int(delta.total_seconds())
        expires_at = _iso(now + delta)
        last_tick_at = _iso(now)
        is_permanent = 0
    else:
        remaining_seconds = None
        expires_at = None
        last_tick_at = None
        is_permanent = 1

    pw_hash = generate_password_hash(password)
    cur = con.execute("""
        INSERT INTO accounts (username, password_hash, is_permanent,
                               remaining_seconds, last_tick_at, expires_at)
        VALUES (?,?,?,?,?,?)
    """, (username, pw_hash, is_permanent, remaining_seconds, last_tick_at, expires_at))
    con.commit()
    return cur.lastrowid


def get_account_by_username(con, username):
    return con.execute("SELECT * FROM accounts WHERE username=?", (username,)).fetchone()


def get_account_by_id(con, account_id):
    return con.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()


def get_account_by_session(con, session_token):
    if not session_token:
        return None
    return con.execute("SELECT * FROM accounts WHERE session_token=?", (session_token,)).fetchone()


def check_password(row, password):
    return bool(row) and check_password_hash(row["password_hash"], password)


def is_expired(row):
    if row is None:
        return True
    if row["is_permanent"]:
        return False
    rem = row["remaining_seconds"]
    if rem is None:
        return False
    return rem <= 0


def remaining_label(row):
    if row["is_permanent"]:
        return "Permanent"
    rem = row["remaining_seconds"]
    if rem is None:
        return "Permanent"
    if rem <= 0:
        return "Expired"
    days = rem // 86400
    hours = (rem % 86400) // 3600
    minutes = (rem % 3600) // 60
    parts = []
    if days:
        parts.append(f"{days}h")
    if hours:
        parts.append(f"{hours}j")
    if minutes and not days:
        parts.append(f"{minutes}m")
    return " ".join(parts) if parts else "< 1m"


def bind_device(con, account_id, device_id, fingerprint, session_token,
                 meta=None, user_agent="", ip=""):
    meta = meta or {}
    now = _iso(_now())
    row = get_account_by_id(con, account_id)
    first_login = row["first_login_at"] or now
    con.execute("""
        UPDATE accounts SET
            session_token = ?,
            device_id = ?,
            device_fingerprint = ?,
            device_name = ?,
            device_os = ?,
            device_browser = ?,
            device_platform = ?,
            device_public_ip = ?,
            device_timezone = ?,
            device_language = ?,
            device_screen = ?,
            device_user_agent = ?,
            first_login_at = ?,
            last_login_at = ?,
            last_active_at = ?
        WHERE id = ?
    """, (
        session_token, device_id, fingerprint,
        meta.get("device_name", ""), meta.get("os", ""), meta.get("browser", ""),
        meta.get("platform", ""), ip, meta.get("timezone", ""), meta.get("language", ""),
        meta.get("screen", ""), user_agent,
        first_login, now, now, account_id
    ))
    con.commit()


def touch_last_active(con, account_id):
    con.execute("UPDATE accounts SET last_active_at=? WHERE id=?", (_iso(_now()), account_id))
    con.commit()


def clear_session(con, account_id):
    """Log the current device out (cookie invalidated) but keep the device
    binding intact, so the same device can log back in without conflict."""
    con.execute("UPDATE accounts SET session_token=NULL WHERE id=?", (account_id,))
    con.commit()


def reset_device(con, account_id):
    """Fully unbind the device — a new device may now log in."""
    con.execute("""
        UPDATE accounts SET
            session_token=NULL, device_id=NULL, device_fingerprint=NULL,
            device_name=NULL, device_os=NULL, device_browser=NULL,
            device_platform=NULL, device_public_ip=NULL, device_timezone=NULL,
            device_language=NULL, device_screen=NULL, device_user_agent=NULL
        WHERE id=?
    """, (account_id,))
    con.commit()


def is_locked(row):
    return bool(row is not None and row["is_locked"])


def set_locked(con, account_id, locked):
    """Lock/unlock an account. Locking does NOT touch the session or
    device binding — the device stays 'logged in' but every request is
    met with the lock screen instead of the site, until unlocked. This
    is permanent and survives restarts (plain DB column, no expiry)."""
    con.execute("UPDATE accounts SET is_locked=? WHERE id=?", (1 if locked else 0, account_id))
    con.commit()


def add_duration(con, account_id, duration_token):
    """Extend an account's remaining budget. Empty/None token -> make permanent."""
    row = get_account_by_id(con, account_id)
    if not row:
        raise AccountError("Account not found.")

    now = _now()

    if not duration_token:
        con.execute("""
            UPDATE accounts SET is_permanent=1, remaining_seconds=NULL,
                                 last_tick_at=NULL, expires_at=NULL
            WHERE id=?
        """, (account_id,))
        con.commit()
        return

    delta_seconds = int(parse_duration(duration_token).total_seconds())
    current_remaining = row["remaining_seconds"] or 0
    if row["is_permanent"]:
        current_remaining = 0
    new_remaining = max(current_remaining, 0) + delta_seconds
    new_expires_est = _iso(now + timedelta(seconds=new_remaining))
    last_tick = row["last_tick_at"] or _iso(now)

    con.execute("""
        UPDATE accounts SET
            is_permanent=0, remaining_seconds=?, expires_at=?, last_tick_at=?
        WHERE id=?
    """, (new_remaining, new_expires_est, last_tick, account_id))
    con.commit()


def remove_account(con, account_id):
    con.execute("DELETE FROM accounts WHERE id=?", (account_id,))
    con.commit()


def list_accounts(con, search=None, sort=None):
    sql = "SELECT * FROM accounts"
    params = []
    if search:
        sql += " WHERE username LIKE ?"
        params.append(f"%{search}%")

    order_map = {
        "username":      "username COLLATE NOCASE ASC",
        "created":       "created_at DESC",
        "expires":       "remaining_seconds ASC",
        "permanent":     "is_permanent DESC",
        "recent_login":  "last_login_at DESC",
    }
    sql += " ORDER BY " + order_map.get(sort, "created_at DESC")

    rows = con.execute(sql, params).fetchall()
    return rows


def get_stats(con):
    rows = con.execute("SELECT * FROM accounts").fetchall()
    total = len(rows)
    active = 0
    expired = 0
    permanent = 0
    online_devices = 0
    for r in rows:
        if r["is_permanent"]:
            permanent += 1
        if is_expired(r):
            expired += 1
        else:
            active += 1
        if r["device_id"]:
            online_devices += 1
    return {
        "total": total,
        "active": active,
        "expired": expired,
        "permanent": permanent,
        "devices_bound": online_devices,
    }


# ── Pausable countdown engine ────────────────────────────────────────────────
# Call resume_accounts() exactly once when a backend process starts, then
# call tick_accounts() periodically (e.g. every 10-30s) for as long as that
# process stays alive. Together these make remaining_seconds only ever
# decrease while something is actually running.

def resume_accounts(con):
    """Reset the tick reference point to now for every timed account,
    WITHOUT subtracting any elapsed time. This is what makes downtime
    (the backend being off) invisible to the countdown."""
    con.execute(
        "UPDATE accounts SET last_tick_at=? "
        "WHERE is_permanent=0 AND remaining_seconds IS NOT NULL",
        (_iso(_now()),)
    )
    con.commit()


def tick_accounts(con):
    """Subtract real elapsed time (since the last tick) from every timed,
    still-active account's remaining budget. Safe to call from multiple
    processes — each tick only accounts for the small gap since the last
    tick was recorded in the database."""
    now = _now()
    rows = con.execute("""
        SELECT id, remaining_seconds, last_tick_at FROM accounts
        WHERE is_permanent=0 AND remaining_seconds IS NOT NULL
          AND remaining_seconds > 0 AND last_tick_at IS NOT NULL
    """).fetchall()

    for r in rows:
        last = _parse_iso(r["last_tick_at"])
        if last is None:
            continue
        elapsed = (now - last).total_seconds()
        if elapsed <= 0:
            continue
        new_remaining = max(0, r["remaining_seconds"] - int(elapsed))
        new_expires_est = _iso(now + timedelta(seconds=new_remaining))
        con.execute(
            "UPDATE accounts SET remaining_seconds=?, last_tick_at=?, expires_at=? WHERE id=?",
            (new_remaining, _iso(now), new_expires_est, r["id"])
        )
    con.commit()

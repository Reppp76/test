"""
app/ip_locks.py
----------------
IP-address-level lock, controlled via the Telegram bot (/lock, /unlock).

This is separate from and independent of the per-account lock in
app/accounts.py (is_locked column). An IP lock blocks that IP from
BOTH the public portal (8980) AND the admin panel (8089), regardless
of which account or session is used — it's checked before any
account/session logic runs.

Permanent by design: a plain DB row, no expiry, no ticking engine.
It only goes away when an admin explicitly runs /unlock.
"""

from datetime import datetime


def _now():
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")


def ensure_schema(con):
    con.executescript("""
        CREATE TABLE IF NOT EXISTS ip_locks (
            ip         TEXT PRIMARY KEY,
            locked_at  TEXT DEFAULT (datetime('now')),
            locked_by  TEXT
        );
    """)
    con.commit()


def lock_ip(con, ip, locked_by=None):
    ip = (ip or "").strip()
    con.execute("""
        INSERT INTO ip_locks (ip, locked_at, locked_by) VALUES (?,?,?)
        ON CONFLICT(ip) DO UPDATE SET locked_at=excluded.locked_at, locked_by=excluded.locked_by
    """, (ip, _now(), str(locked_by or "")))
    con.commit()


def unlock_ip(con, ip):
    ip = (ip or "").strip()
    con.execute("DELETE FROM ip_locks WHERE ip=?", (ip,))
    con.commit()


def is_ip_locked(con, ip):
    ip = (ip or "").strip()
    if not ip:
        return False
    row = con.execute("SELECT 1 FROM ip_locks WHERE ip=?", (ip,)).fetchone()
    return row is not None

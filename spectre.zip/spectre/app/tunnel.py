"""
app/tunnel.py
---------------
Wraps a single `cloudflared tunnel --url http://localhost:<port>` process.
Started once from run.py after the public portal is up; the assigned
*.trycloudflare.com URL is read from cloudflared's own output (never
guessed or hardcoded) and handed out to telegram_bot.handle_create via
get_url() / wait_for_url(). One tunnel per `python run.py` session —
stop() + start() again gets you a fresh URL.
"""

import re
import subprocess
import threading
import logging

log = logging.getLogger("spectre.tunnel")

_URL_RE = re.compile(r"https://[a-zA-Z0-9\-]+\.trycloudflare\.com")

_proc = None
_url = None
_ready = threading.Event()
_lock = threading.Lock()


def _watch(stream):
    global _url
    for line in iter(stream.readline, ""):
        match = _URL_RE.search(line)
        if not match:
            continue
        url = match.group(0)
        if url.startswith("https://api.trycloudflare.com"):
            continue  # not the quick-tunnel URL, just Cloudflare's own API host
        with _lock:
            _url = url
        if not _ready.is_set():
            log.info(f"Cloudflared tunnel ready → {url}")
            _ready.set()
    stream.close()


def start(port):
    """Spawn cloudflared for the given local port. No-op if already running."""
    global _proc
    with _lock:
        if _proc is not None and _proc.poll() is None:
            return
        try:
            _proc = subprocess.Popen(
                ["cloudflared", "tunnel", "--url", f"http://localhost:{port}"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
        except FileNotFoundError:
            log.error("cloudflared binary not found on PATH — tunnel not started.")
            return

    threading.Thread(target=_watch, args=(_proc.stdout,), daemon=True, name="cloudflared-watch").start()


def wait_for_url(timeout=30):
    """Block until the tunnel URL is known, or return None after timeout."""
    if _ready.wait(timeout):
        with _lock:
            return _url
    return None


def get_url():
    with _lock:
        return _url


def stop():
    global _proc
    with _lock:
        proc, _proc = _proc, None
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()

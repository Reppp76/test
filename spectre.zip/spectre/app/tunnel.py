"""
app/tunnel.py — Cloudflared quick-tunnel for the public portal
================================================================
Exposes get_tunnel_url(), used by telegram_bot.handle_create() so every
"/create" in a running session shares ONE tunnel to localhost:8980.

Nothing here touches accounts.py, roles.py, ip_locks.py, or any Flask
route/template — it only manages a cloudflared subprocess and the URL
it prints on startup.

State lives in memory for the lifetime of this process (run.py or
telegram_bot.py standalone). Quick Tunnel URLs aren't stable across
restarts, so nothing is persisted to the database — a fresh session
is free to get a new URL.
"""

import re
import shutil
import subprocess
import threading

PORTAL_URL = "http://localhost:8980"
TUNNEL_CMD = ["cloudflared", "tunnel", "--url", PORTAL_URL]
URL_WAIT_SECONDS = 30

_URL_RE = re.compile(r"https://[a-zA-Z0-9\-]+\.trycloudflare\.com")

_lock = threading.Lock()
_process = None
_url = None


class TunnelError(Exception):
    pass


def _alive():
    return _process is not None and _process.poll() is None


def _drain_stdout(proc, found):
    """Reads cloudflared's output for the lifetime of the process. Grabs
    the tunnel URL the first time it appears, then just keeps reading so
    the pipe never backs up and blocks cloudflared."""
    global _url
    try:
        for line in proc.stdout:
            if _url is None:
                match = _URL_RE.search(line)
                if match:
                    _url = match.group(0)
                    found.set()
    except Exception:
        pass


def _start_process():
    global _process, _url

    if shutil.which("cloudflared") is None:
        raise TunnelError(
            "cloudflared tidak dijumpai dalam PATH. Pasang dahulu "
            "(cth. pkg install cloudflared di Termux)."
        )

    _url = None
    _process = subprocess.Popen(
        TUNNEL_CMD,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    found = threading.Event()
    threading.Thread(target=_drain_stdout, args=(_process, found), daemon=True).start()

    if not found.wait(URL_WAIT_SECONDS) or not _url:
        _process.terminate()
        _process = None
        _url = None
        raise TunnelError("Cloudflared tidak menghasilkan URL dalam masa yang ditetapkan.")


def get_tunnel_url():
    """Returns the session's tunnel URL, starting cloudflared if it
    isn't already running. Safe to call concurrently — only one
    tunnel is ever started per session."""
    global _process, _url

    with _lock:
        if _alive() and _url:
            return _url

        if _process is not None and not _alive():
            _process = None
            _url = None

        _start_process()
        return _url

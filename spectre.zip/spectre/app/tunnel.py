"""
app/tunnel.py — Cloudflared quick-tunnel for the public portal
================================================================
Exposes get_tunnel_url(), used by telegram_bot.handle_create() so every
"/create" in a running session shares ONE tunnel to localhost:8980.

A URL is only ever handed back once it's been confirmed to actually
work — hostname resolves AND the tunnel answers an HTTP request — not
just because cloudflared printed it. cloudflared logs a quick-tunnel
URL slightly before Cloudflare's edge has finished registering it, so
using the raw log line as-is is what was producing ERR_NAME_NOT_RESOLVED.

Nothing here touches accounts.py, roles.py, ip_locks.py, or any Flask
route/template — it only manages a cloudflared subprocess and validates
the URL it prints on startup.

State lives in memory for the lifetime of this process (run.py or
telegram_bot.py standalone). Quick Tunnel URLs aren't stable across
restarts, so nothing is persisted to the database — a fresh session
is free to get a new URL.
"""

import re
import shutil
import socket
import subprocess
import threading
import time
from urllib.parse import urlparse

import requests

PORTAL_HOST = "localhost"
PORTAL_PORT = 8980
PORTAL_URL = f"http://{PORTAL_HOST}:{PORTAL_PORT}"
TUNNEL_CMD = ["cloudflared", "tunnel", "--url", PORTAL_URL]

LOCAL_READY_TIMEOUT = 10           # wait for the Flask portal itself to open
URL_LOG_TIMEOUT = 30               # wait for cloudflared to print a URL at all
READY_CHECK_BACKOFF = (1, 1, 2, 2, 3, 3, 5, 5)  # DNS+HTTP retry pacing, seconds

_URL_RE = re.compile(r"https://[a-zA-Z0-9\-]+\.trycloudflare\.com")

_lock = threading.Lock()
_process = None
_url = None


class TunnelError(Exception):
    pass


def _alive():
    return _process is not None and _process.poll() is None


def _local_portal_ready():
    """Confirms the Flask public portal is actually listening on
    localhost:8980 before cloudflared is pointed at it."""
    deadline = time.time() + LOCAL_READY_TIMEOUT
    while time.time() < deadline:
        try:
            with socket.create_connection((PORTAL_HOST, PORTAL_PORT), timeout=2):
                return True
        except OSError:
            time.sleep(0.5)
    return False


def _drain_stdout(proc, found):
    """Reads cloudflared's combined stdout/stderr for the process's whole
    lifetime — grabs the tunnel URL the first time it appears, then keeps
    reading so the pipe never backs up and blocks cloudflared."""
    global _url
    try:
        for line in proc.stdout:
            if _url is None:
                match = _URL_RE.search(line)
                if match:
                    _url = match.group(0)
                    found.set()
    except Exception:
        pass


def _hostname_resolves(url):
    host = urlparse(url).hostname
    try:
        socket.gethostbyname(host)
        return True
    except OSError:
        return False


def _tunnel_reachable(url):
    try:
        requests.get(url, timeout=(5, 10))
        return True
    except requests.exceptions.RequestException:
        return False


def _wait_until_ready(url):
    """DNS then HTTP validation, retried with backoff — a fresh
    trycloudflare.com hostname can take a few seconds to become
    resolvable/routable after cloudflared logs it."""
    for wait in READY_CHECK_BACKOFF:
        if not _alive():
            return False
        if _hostname_resolves(url) and _tunnel_reachable(url):
            return True
        time.sleep(wait)
    return _alive() and _hostname_resolves(url) and _tunnel_reachable(url)


def _start_process():
    global _process, _url

    if shutil.which("cloudflared") is None:
        raise TunnelError(
            "cloudflared tidak dijumpai dalam PATH. Pasang dahulu "
            "(cth. pkg install cloudflared di Termux)."
        )

    if not _local_portal_ready():
        raise TunnelError(
            "Public portal (localhost:8980) belum sedia — tunnel tidak dimulakan."
        )

    _url = None
    _process = subprocess.Popen(
        TUNNEL_CMD,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    found = threading.Event()
    threading.Thread(target=_drain_stdout, args=(_process, found), daemon=True).start()

    if not found.wait(URL_LOG_TIMEOUT) or not _url:
        _process.terminate()
        _process = None
        _url = None
        raise TunnelError("Cloudflared tidak menghasilkan URL dalam masa yang ditetapkan.")

    candidate = _url
    if not _wait_until_ready(candidate):
        if _process is not None:
            _process.terminate()
        _process = None
        _url = None
        raise TunnelError(
            "Tunnel Cloudflared tidak dapat disahkan (DNS/HTTP gagal selepas beberapa cubaan)."
        )


def get_tunnel_url():
    """Returns the session's validated tunnel URL, starting and verifying
    cloudflared if it isn't already running. Safe to call concurrently —
    only one tunnel is ever started per session, and a URL is only ever
    handed out after DNS + HTTP have confirmed it actually works."""
    global _process, _url

    with _lock:
        if _alive() and _url:
            return _url

        if _process is not None and not _alive():
            _process = None
            _url = None

        _start_process()
        return _url

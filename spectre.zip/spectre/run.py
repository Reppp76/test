"""
run.py — SPECTRE OSINT Platform launcher
==========================================
Starts TWO separate Flask servers in parallel threads:

  Public portal  → http://0.0.0.0:8980   (anyone can access)
  Admin panel    → http://0.0.0.0:8089   (IP-restricted, see ADMIN_ALLOWED_IPS)

Usage:
  python run.py

Environment variables:
  SECRET_KEY         — Flask secret key (change in production!)
  ADMIN_ALLOWED_IPS  — Comma-separated IPs allowed to access admin
                       e.g. "192.168.1.5,10.0.0.3"
                       Localhost (127.0.0.1 / ::1) is always allowed.
"""

import os
import threading
import logging
from app import create_public_app, create_admin_app
import telegram_bot

PUBLIC_HOST = "0.0.0.0"
PUBLIC_PORT = 8980

ADMIN_HOST  = "0.0.0.0"
ADMIN_PORT  = 8089


def _fatal(component, exc):
    # A failed create_public_app()/create_admin_app() must not be allowed
    # to pass as a working startup just because the other two threads came
    # up fine — kill the whole process so the failure is obvious instead of
    # silently running with a missing portal.
    logging.getLogger("spectre").critical(
        f"{component} failed to initialise — aborting startup.", exc_info=exc
    )
    os._exit(1)


def run_public():
    try:
        app = create_public_app()
    except Exception as exc:
        _fatal("Public portal", exc)
        return
    app.logger.info(f"Public portal  → http://{PUBLIC_HOST}:{PUBLIC_PORT}")
    # use_reloader=False is required when running in threads
    app.run(host=PUBLIC_HOST, port=PUBLIC_PORT,
            debug=False, use_reloader=False, threaded=True)


def run_admin():
    try:
        app = create_admin_app()
    except Exception as exc:
        _fatal("Admin panel", exc)
        return
    app.logger.info(f"Admin panel    → http://{ADMIN_HOST}:{ADMIN_PORT}")
    app.run(host=ADMIN_HOST, port=ADMIN_PORT,
            debug=False, use_reloader=False, threaded=True)


def run_telegram_bot():
    # Runs the same long-polling loop as `python telegram_bot.py`, just
    # inside this process instead of a separate one. Safe to leave
    # running even before a real bot token is configured — it waits
    # quietly until one is set via the admin panel.
    try:
        telegram_bot.main()
    except Exception:
        logging.getLogger("spectre.bot").exception("Telegram bot thread crashed")


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] %(levelname)s %(message)s"
    )

    print("""
  ╔══════════════════════════════════════════════════════╗
  ║          S P E C T R E   O S I N T   P O R T A L    ║
  ╠══════════════════════════════════════════════════════╣
  ║  Public portal  →  http://0.0.0.0:8980              ║
  ║  Admin panel    →  http://0.0.0.0:8089              ║
  ║  Telegram bot   →  running in background             ║
  ║                                                      ║
  ║  Admin is IP-restricted (localhost by default).      ║
  ║  Set ADMIN_ALLOWED_IPS env to add more IPs.          ║
  ╚══════════════════════════════════════════════════════╝
    """)

    t_public = threading.Thread(target=run_public, daemon=True, name="public")
    t_admin  = threading.Thread(target=run_admin,  daemon=True, name="admin")
    t_bot    = threading.Thread(target=run_telegram_bot, daemon=True, name="telegram-bot")

    t_public.start()
    t_admin.start()
    t_bot.start()

    # Keep main thread alive
    try:
        t_public.join()
        t_admin.join()
        t_bot.join()
    except KeyboardInterrupt:
        print("\n[SPECTRE] Shutting down.")

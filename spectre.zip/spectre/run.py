"""
run.py — SPECTRE OSINT Platform launcher
==========================================
Starts TWO separate Flask servers in parallel threads:

  Public portal  → http://0.0.0.0:8980   (anyone can access)
  Admin panel    → http://0.0.0.0:8089   (IP-restricted, see ADMIN_ALLOWED_IPS)

Usage:
  python run.py

Environment variables:
  SECRET_KEY         — Flask secret key (change in production!)
  ADMIN_ALLOWED_IPS  — Comma-separated IPs allowed to access admin
                       e.g. "192.168.1.5,10.0.0.3"
                       Localhost (127.0.0.1 / ::1) is always allowed.
"""

import os
import re
import socket
import subprocess
import threading
import time
import logging
from app import create_public_app, create_admin_app
import telegram_bot

PUBLIC_HOST = "0.0.0.0"
PUBLIC_PORT = 8980

ADMIN_HOST  = "0.0.0.0"
ADMIN_PORT  = 8089

# ── Cloudflared quick tunnel (public portal only) ───────────────────────────
# One tunnel per `python run.py` process. /create and everything else should
# read TUNNEL_URL (or os.environ["SPECTRE_TUNNEL_URL"]) instead of starting
# a tunnel of their own.

TUNNEL_URL = None
_tunnel_proc = None
_tunnel_log = logging.getLogger("spectre.tunnel")
_QUICK_TUNNEL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")


def _wait_for_port(host, port, timeout=30):
    deadline = time.time() + timeout
    probe_host = "127.0.0.1" if host == "0.0.0.0" else host
    while time.time() < deadline:
        try:
            with socket.create_connection((probe_host, port), timeout=1):
                return True
        except OSError:
            time.sleep(0.5)
    return False


def _drain_tunnel_output(proc, found_event):
    global TUNNEL_URL
    for line in proc.stdout:
        match = _QUICK_TUNNEL_RE.search(line)
        if match and "api.trycloudflare.com" not in match.group(0):
            TUNNEL_URL = match.group(0)
            os.environ["SPECTRE_TUNNEL_URL"] = TUNNEL_URL
            found_event.set()
        # keep reading so cloudflared's stdout buffer never fills up and hangs it


def start_cloudflared(target_port=PUBLIC_PORT, ready_timeout=30, url_timeout=20):
    global _tunnel_proc

    if not _wait_for_port("127.0.0.1", target_port, ready_timeout):
        _tunnel_log.warning(f"Public portal never came up on :{target_port} — cloudflared not started")
        return None

    try:
        _tunnel_proc = subprocess.Popen(
            ["cloudflared", "tunnel", "--url", f"http://localhost:{target_port}"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1,
        )
    except FileNotFoundError:
        _tunnel_log.warning("cloudflared binary not found on PATH — skipping tunnel")
        return None

    found = threading.Event()
    threading.Thread(
        target=_drain_tunnel_output, args=(_tunnel_proc, found),
        daemon=True, name="cloudflared-reader"
    ).start()

    if not found.wait(url_timeout):
        _tunnel_log.warning("cloudflared didn't report a tunnel URL in time")
        return None

    _tunnel_log.info(f"Cloudflared tunnel ready → {TUNNEL_URL}")
    return TUNNEL_URL


def stop_cloudflared():
    if _tunnel_proc and _tunnel_proc.poll() is None:
        _tunnel_proc.terminate()
        try:
            _tunnel_proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            _tunnel_proc.kill()


def run_public():
    app = create_public_app()
    app.logger.info(f"Public portal  → http://{PUBLIC_HOST}:{PUBLIC_PORT}")
    # use_reloader=False is required when running in threads
    app.run(host=PUBLIC_HOST, port=PUBLIC_PORT,
            debug=False, use_reloader=False, threaded=True)


def run_admin():
    app = create_admin_app()
    app.logger.info(f"Admin panel    → http://{ADMIN_HOST}:{ADMIN_PORT}")
    app.run(host=ADMIN_HOST, port=ADMIN_PORT,
            debug=False, use_reloader=False, threaded=True)


def run_telegram_bot():
    # Runs the same long-polling loop as `python telegram_bot.py`, just
    # inside this process instead of a separate one. Safe to leave
    # running even before a real bot token is configured — it waits
    # quietly until one is set via the admin panel.
    try:
        telegram_bot.main()
    except Exception:
        logging.getLogger("spectre.bot").exception("Telegram bot thread crashed")


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] %(levelname)s %(message)s"
    )

    print("""
  ╔══════════════════════════════════════════════════════╗
  ║          S P E C T R E   O S I N T   P O R T A L    ║
  ╠══════════════════════════════════════════════════════╣
  ║  Public portal  →  http://0.0.0.0:8980              ║
  ║  Admin panel    →  http://0.0.0.0:8089              ║
  ║  Telegram bot   →  running in background             ║
  ║                                                      ║
  ║  Admin is IP-restricted (localhost by default).      ║
  ║  Set ADMIN_ALLOWED_IPS env to add more IPs.          ║
  ╚══════════════════════════════════════════════════════╝
    """)

    t_public = threading.Thread(target=run_public, daemon=True, name="public")
    t_admin  = threading.Thread(target=run_admin,  daemon=True, name="admin")
    t_bot    = threading.Thread(target=run_telegram_bot, daemon=True, name="telegram-bot")

    t_public.start()
    t_admin.start()
    t_bot.start()

    t_tunnel = threading.Thread(target=start_cloudflared, daemon=True, name="cloudflared")
    t_tunnel.start()

    # Keep main thread alive
    try:
        t_public.join()
        t_admin.join()
        t_bot.join()
    except KeyboardInterrupt:
        print("\n[SPECTRE] Shutting down.")
        stop_cloudflared()
